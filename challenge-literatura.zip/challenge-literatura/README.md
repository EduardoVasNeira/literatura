Readme
Desarrollo solicitado para challenge.