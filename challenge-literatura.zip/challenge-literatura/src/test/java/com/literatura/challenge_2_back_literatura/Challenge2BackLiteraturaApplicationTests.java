package com.literatura.challenge_2_back_literatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Challenge2BackLiteraturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
